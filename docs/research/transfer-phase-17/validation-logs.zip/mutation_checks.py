import copy
import sys
from pathlib import Path
root=Path('/workspace/Project-Simurgh')
sys.path.insert(0,str(root/'tools/assurance-transfer'))
from transfer_study import read_pack,verify_comparison,verify_files
from transfer_deps import loads,wire
sys.path.insert(0,str(root/'tools/assurance-provider-role'))
from corrected_roles import verify as role_verify
p=root/'docs/research/transfer-phase-17'
files=read_pack(p/'evidence.zip',(p/'ROOT.sha256').read_text().strip())
cap=loads(files['llama.json']);raw={n[6:]:v for n,v in files.items() if n.startswith('llama/')}
count=0
def rejects(name,fn,expected):
 global count
 try:fn()
 except ValueError as e:
  if expected not in str(e):raise AssertionError((name,str(e),expected))
 else:raise AssertionError(name+' accepted mutation')
 count+=1;print(name,'REJECTED',expected,flush=True)
for name,alter,reason in [
 ('empty generations',lambda c:c.update(generations=[]),'generation_inventory'),
 ('duplicate generation',lambda c:c['generations'].__setitem__(1,copy.deepcopy(c['generations'][0])),'generation_inventory'),
 ('changed proposal',lambda c:c['generations'][0].update(proposal={'status':'invalid'}),'proposal_mismatch'),
 ('cross-control relabel',lambda c:c['rows'][0].update(control='composed'),'branch_linkage'),
 ('invented receiver effects',lambda c:c['rows'][0].update(new_effects=[]),'raw_snapshot_mismatch')]:
 c=copy.deepcopy(cap);alter(c);rejects(name,lambda:verify_comparison(c,raw,replay=False),reason)
for name,member,alter,reason in [
 ('changed report','report.json',lambda r:r['models']['llama']['controls']['composed'].update(active_completions=24),'report_mismatch')]:
 f=dict(files);v=loads(f[member]);alter(v);f[member]=wire(v);rejects(name,lambda:verify_files(f,replay=False),reason)
f=dict(files);ledger=[loads(x) for x in f['budget.jsonl'].splitlines()];ledger[0]['reserved_usd']='0';f['budget.jsonl']=b''.join(wire(x) for x in ledger)
rejects('erased budget reservation',lambda:verify_files(f,replay=False),'budget_ledger')
p=root/'docs/research/provider-role-phase-17b';roles=read_pack(p/'evidence.zip',(p/'ROOT.sha256').read_text().strip())
f=dict(roles);f['original-budget.jsonl']+=b'\n';rejects('changed original ledger',lambda:role_verify(f),'original_evidence_binding')
f=dict(roles);c=loads(f['capture.json']);c['rows'][0]['first']['request']['input'][1]['role']='user';f['capture.json']=wire(c)
rejects('downgraded host role',lambda:role_verify(f),'api_request_binding')
f=dict(roles);c=loads(f['capture.json']);c['rows'][1]=copy.deepcopy(c['rows'][0]);f['capture.json']=wire(c)
rejects('duplicate corrected workflow',lambda:role_verify(f),'workflow_inventory')
print('mutation checks passed:',count)

import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
root=Path('/workspace/Project-Simurgh')
out=Path('/workspace/work/simurgh-full-smoke-2026-10-19/rerun')
checkout=out/'supplement-checkout'
tools=Path('/workspace/simurgh-research/phase-15')
source=json.loads((out/'environment.json').read_text())['source_commit']
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('API_KEY','TOKEN','SECRET','PASSWORD'))}
env.update(PATH=':'.join(json.loads((out/'environment.json').read_text())['path_prefixes'])+':'+env['PATH'],PYTHONDONTWRITEBYTECODE='1',NO_COLOR='1',ELAN_HOME=str(tools/'toolchains/elan'))
with (out/'supplement-setup.log').open('w') as log:
 subprocess.run(['git','clone','--local','--no-hardlinks',str(root),str(checkout)],check=True,stdout=log,stderr=subprocess.STDOUT)
 subprocess.run(['git','checkout','--detach',source],cwd=checkout,check=True,stdout=log,stderr=subprocess.STDOUT)
 subprocess.run(['git','fetch',str(root),'refs/remotes/origin/main:refs/remotes/origin/main'],cwd=checkout,check=True,stdout=log,stderr=subprocess.STDOUT)
shutil.copytree(root/'node_modules',checkout/'node_modules',symlinks=True)
shutil.copytree(root/'tools/simurgh-explorer/node_modules',checkout/'tools/simurgh-explorer/node_modules',symlinks=True)
logs=out/'supplement-logs';logs.mkdir()
rows=[]
def run(name,cmd,scope=None,cwd=checkout,extra_env=None,timeout=1200):
 localenv=env.copy();localenv.update(extra_env or {})
 log=logs/(name+'.log');start=time.monotonic()
 with log.open('w') as f:
  try: rc=subprocess.run(cmd,cwd=cwd,env=localenv,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:rc=124
 text=log.read_text();count=re.search(r'Ran (\d+) tests? in ',text)
 rows.append({'name':name,'command':cmd,'scope':scope,'source_commit':source,'exit_code':rc,'tests':int(count[1]) if count else None,'elapsed_seconds':round(time.monotonic()-start,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (out/'supplement-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,rc,rows[-1]['tests'],flush=True)
run('explorer-tests',['npm','--prefix','tools/simurgh-explorer','test'])
run('explorer-build',['npm','--prefix','tools/simurgh-explorer','run','build'])
run('explorer-http-smoke',['node',str(out/'explorer-http-smoke.mjs')])
base=['assurance-workflow','assurance-redis','assurance-durable','assurance-sdk','assurance-isolation','assurance-scope','assurance-egress']
dirs=sorted({p.parent for p in checkout.glob('tools/*/tests/test_*.py')})
(out/'python-inventory.json').write_text(json.dumps([str(d.relative_to(checkout)) for d in dirs],indent=2)+'\n')
for d in dirs:
 if d.parent.name=='agentdojo-simurgh-adapter':
  run('agentdojo-adapter',[str(tools/'pytest-venv/bin/python'),'-m','pytest','tests/','-q'],cwd=d.parent,extra_env={'PYTHONPATH':str(d.parent)})
  continue
 py='/workspace/.venvs/simurgh-assurance-workflow/bin/python'
 path=os.pathsep.join(str(checkout/'tools'/n) for n in dict.fromkeys([d.parent.name,*base]))
 run(d.parent.name,[py,'-B','-m','unittest','discover','-s',str(d.relative_to(checkout)),'-v'],extra_env={'PYTHONPATH':path})
run('browser-parity',['node','scripts/check-browser-parity.mjs',str(out/'browser-parity.json')],scope='real browser prerequisite check; nonzero if unavailable',timeout=180)
(out/'supplement-checkout-status.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=checkout,text=True))

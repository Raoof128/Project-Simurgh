import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/workspace/Project-Simurgh')
out=Path('/workspace/work/simurgh-full-smoke-2026-10-21-final')
tools=Path('/workspace/simurgh-research/phase-15')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('API_KEY','TOKEN','SECRET','PASSWORD'))}
paths=[tools/'node-runtime/node_modules/node/bin',Path('/workspace/.venvs/simurgh-assurance-workflow/bin'),tools/'pytest-venv/bin',tools/'toolchains/elan/toolchains/leanprover--lean4---v4.15.0/bin',tools/'toolchains/cargo/bin',tools/'toolchains/root/usr/bin']
env.update(PATH=':'.join(map(str,paths))+':'+env['PATH'],PYTHONDONTWRITEBYTECODE='1',NO_COLOR='1',CARGO_HOME=str(tools/'toolchains/cargo'),RUSTUP_HOME=str(tools/'toolchains/rustup'),ELAN_HOME=str(tools/'toolchains/elan'),LD_LIBRARY_PATH=str(tools/'toolchains/root/usr/lib/x86_64-linux-gnu'),SIMURGH_NPM_BUILD_CACHE=str(tools/'npm-build-cache'))
(out/'environment.json').write_text(json.dumps({'source_commit':source,'platform':os.uname().sysname,'path_prefixes':list(map(str,paths)),'docker_build':'documented offline lockfile cache','credential_environment':'API_KEY/TOKEN/SECRET/PASSWORD-named variables excluded','dependencies':'root node_modules copied from current prepared checkout'},indent=2)+'\n')
rows=[]
for name,script in [('e2e','scripts/check-e2e.sh')]:
 checkout=out/(name+'-checkout')
 with (out/(name+'-setup.log')).open('w') as log:
  subprocess.run(['git','clone','--local','--no-hardlinks',str(root),str(checkout)],check=True,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['git','checkout','--detach',source],cwd=checkout,check=True,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['git','fetch',str(root),'refs/remotes/origin/main:refs/remotes/origin/main'],cwd=checkout,check=True,stdout=log,stderr=subprocess.STDOUT)
 shutil.copytree(root/'node_modules',checkout/'node_modules',symlinks=True)
 log=out/(name+'.log');start=time.monotonic()
 print(f'Starting {name}: {script} at {source}',flush=True)
 with log.open('w') as f:
  process=subprocess.Popen(['bash',script],cwd=checkout,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  (out/(name+'.pid')).write_text(str(process.pid)+'\n')
  rc=process.wait()
 row={'name':name,'command':['bash',script],'source_commit':source,'exit_code':rc,'elapsed_seconds':round(time.monotonic()-start,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 rows.append(row)
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 (out/(name+'-checkout-status.txt')).write_text(subprocess.check_output(['git','status','--short'],cwd=checkout,text=True))
 print(f'Completed {name}: exit={rc}, seconds={row["elapsed_seconds"]}',flush=True)

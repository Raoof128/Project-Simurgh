import sys,json,re,unicodedata,subprocess
from pathlib import Path
from urllib.parse import unquote,urlsplit
sys.path.insert(0,'/workspace/work/simurgh-docs-audit/parser')
from markdown_it import MarkdownIt
R=Path('/workspace/Project-Simurgh'); md=MarkdownIt('commonmark',{'html':True}).enable('table')
files=subprocess.check_output(['git','ls-files'],cwd=R,text=True).splitlines()
files+= [str(p.relative_to(R)) for p in (R/'docs/documentation-audit-2026-10-19').glob('*.md')]+['DOCUMENTATION.md','docs/INTEGRATIONS.md']
files=sorted(set(files)); cache={}; issues=[];total=0; checked=[]
def parse(p):
 if p not in cache:cache[p]=md.parse(p.read_text())
 return cache[p]
def anchors(p):
 text=p.read_text();s=set(re.findall(r'(?:id|name)=[\"\x27]([^\"\x27]+)',text));seen={};ts=parse(p)
 for i,t in enumerate(ts):
  if t.type!='heading_open':continue
  children=ts[i+1].children or [];h=''.join(c.content for c in children if c.type not in {'html_inline','image'}).lower();h=''.join(c for c in h if c in '_- ' or unicodedata.category(c)[0] in 'LN').replace(' ','-');n=seen.get(h,0);seen[h]=n+1;s.add(h+(f'-{n}' if n else ''))
 return s
for f in files:
 p=R/f
 if not p.is_file() or p.suffix not in {'.md','.html'}:continue
 targets=[]
 if p.suffix=='.md':
  for t in parse(p):
   for c in t.children or []:
    if c.type in {'link_open','image'}:targets.append((c.attrGet('href') or c.attrGet('src'),t.map[0]+1 if t.map else None))
    if c.type=='html_inline':targets += [(u,t.map[0]+1 if t.map else None) for u in re.findall(r'(?:href|src)=[\"\x27]([^\"\x27]+)',c.content)]
   if t.type=='html_block':targets +=[(u,t.map[0]+1 if t.map else None) for u in re.findall(r'(?:href|src)=[\"\x27]([^\"\x27]+)',t.content)]
 else:targets=[(u,None) for u in re.findall(r'(?:href|src)=[\"\x27]([^\"\x27]+)',p.read_text())]
 for u,line in targets:
  if not u or urlsplit(u).scheme or u.startswith('//'):continue
  raw,_,frag=u.partition('#');raw=unquote(raw.split('?')[0]);frag=unquote(frag)
  if p.suffix=='.html' and raw.startswith('/'):continue
  if any(x in raw for x in '{}<>*'):continue
  dest=((R/raw.lstrip('/')) if raw.startswith('/') else p.parent/raw).resolve() if raw else p
  total+=1;status=None
  if not dest.exists():status='missing_path'
  elif frag and dest.suffix=='.md' and frag not in anchors(dest):status='missing_anchor'
  elif frag and dest.suffix=='.html' and frag not in set(re.findall(r'(?:id|name)=[\"\x27]([^\"\x27]+)',dest.read_text())):status='missing_html_anchor'
  entry=dict(path=f,line=line,target=u,status=status or 'resolved');checked.append(entry)
  if status:issues.append(entry)
Path('/workspace/work/simurgh-readiness-2026-10-21/links.json').write_text(json.dumps(dict(total=total,issues=issues,checked=checked),indent=2)+'\n')
print('local_links',total,'issues',len(issues))
for x in issues:print(json.dumps(x))

import hashlib,json,os,re,subprocess,zipfile
from pathlib import Path
root=Path('/workspace/Project-Simurgh')
work=Path('/workspace/work/simurgh-readiness-2026-10-21')
initial=Path('/workspace/work/simurgh-full-smoke-2026-10-21')
candidate=Path('/workspace/work/simurgh-full-smoke-2026-10-21-candidate')
final=Path('/workspace/work/simurgh-full-smoke-2026-10-21-final')
dest=root/'docs/readiness-2026-10-21'
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def counts(p):return {k:int(v) for k,v in re.findall(r'(?:#|ℹ)\s+(tests|pass|fail|skipped|cancelled|todo)\s+(\d+)',p.read_text())}
def steps(p):
 s=p.read_text();return {'passed':int(re.findall(r'Passed:\s*(\d+)',s)[-1]),'failed':int(re.findall(r'Failed:\s*(\d+)',s)[-1])}
base=next(r for r in read(candidate/'results.json') if r['name']=='base')
e2e=read(final/'results.json')[0]
assert base['exit_code']==e2e['exit_code']==0
assert steps(candidate/'base.log')=={'passed':142,'failed':0}
assert steps(final/'e2e.log')=={'passed':32,'failed':0}
unit=counts(work/'root-final.log');e2ec=counts(final/'e2e-checkout/.simurgh_check_logs/e2e_e2e_nets.log');explorer=counts(work/'explorer-final-revision.log')
for c in (unit,e2ec,explorer):assert c['tests']>0 and c['fail']==c['skipped']==0
supplement=read(candidate/'supplement-results.json');suites=[r for r in supplement if r['tests'] is not None]
assert len(suites)==29 and all(r['tests']>0 and r['exit_code']==0 for r in suites)
assert not [r for r in supplement if r['exit_code'] and r['name']!='browser-parity']
pytest=int(re.findall(r'(\d+) passed',(candidate/'supplement-logs/agentdojo-adapter.log').read_text())[-1])
rust_matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (candidate/'base-checkout/.simurgh_check_logs/stage28-rust-gates.log').read_text())
rust={'passed':sum(int(r[0]) for r in rust_matches),'failed':sum(int(r[1]) for r in rust_matches),'ignored':sum(int(r[2]) for r in rust_matches)}
assert rust['passed']>0 and rust['failed']==rust['ignored']==0
browser=read(candidate/'browser-parity.json');assert browser['two_runtime_parity'] and not browser['three_runtime_parity']
native=read(work/'native-validation.json');hosted=read(work/'hosted-readiness.json')
assert native['conclusion']==hosted['conclusion']=='success'
assert all(j['conclusion']=='success' for j in native['jobs']+hosted['jobs'])
source=e2e['source_commit'];assert source.startswith('8155106a')
delta=subprocess.check_output(['git','diff','--name-only',base['source_commit'],source],cwd=root,text=True).splitlines()
allowed_runtime={'tools/simurgh-explorer/core.mjs','tools/simurgh-explorer/tests/transfer.test.mjs','tests/e2e/llmShield/stage4u/k7AllFunctions.test.js','tests/unit/llmShield/stage5p/rawCodeCensus.test.js'}
assert all(p in allowed_runtime or p.startswith('docs/') or p in ('AGENT.md','CHANGELOG.md') for p in delta)
entries={}
def add(p,name):
 if p.is_file(): entries[name.replace(':','_')]=p
for label,folder in [('initial',initial),('candidate',candidate),('final',final)]:
 for name in ('run.py','supplement.py','environment.json','results.json','supplement-results.json','python-inventory.json','browser-parity.json','reference-preflight.json','e2e-reference-preflight.log','pytest-preflight.log','base.log','e2e.log','base-setup.log','e2e-setup.log','base-checkout-status.txt','e2e-checkout-status.txt','supplement-checkout-status.txt'):
  add(folder/name,f'{label}/{name}')
 for p in sorted((folder/'supplement-logs').glob('*.log')):add(p,f'{label}/supplement/{p.name}')
 for stage in ('base','e2e'):
  for p in sorted((folder/(stage+'-checkout')/'.simurgh_check_logs').glob('*.log')):add(p,f'{label}/{stage}-steps/{p.name}')
for p in work.glob('*.log'):add(p,'focused/'+p.name)
for name in ('native-validation.json','hosted-readiness.json','explorer-final-revision-http.json','explorer-http-smoke.mjs','links.json','links.py','provider-capability.json','refusal-retry-2-declaration.json','publish.py'):add(work/name,'focused/'+name)
for run in ('refusal-run','refusal-retry-2'):
 for p in (work/run).glob('*.json*'):add(p,f'{run}/{p.name}')
 for p in (work/run/'api').glob('*.json*'):add(p,f'{run}/api/{p.name}')
secrets=[(k,v.encode()) for k,v in os.environ.items() if len(v)>20 and any(x in k.upper() for x in ('API_KEY','TOKEN','SECRET','PASSWORD'))]
for name,p in entries.items():
 data=p.read_bytes()
 for key,value in secrets: assert value not in data, f'Secret-pattern review needed for {key} in {name}'
 assert not re.search(rb'-----BEGIN (?:[A-Z ]+)?PRIVATE KEY-----|sk-proj-[A-Za-z0-9_-]{30,}|github_pat_[A-Za-z0-9_]{30,}',data),name
manifest=[{'path':name,'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in sorted(entries.items())]
archive=dest/'logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
validation={'schema':'simurgh.readiness.validation.v1','date':'2026-10-21','timezone':'Australia/Sydney','final_code_revision':source,
 'base':{'command':base,'steps':steps(candidate/'base.log')},'e2e':{'command':e2e,'steps':steps(final/'e2e.log'),'tests':e2ec},
 'root':{'source_commit':source,'command':['npm','test'],'counts':unit},'explorer':{'source_commit':source,'commands':[['npm','--prefix','tools/simurgh-explorer','test'],['npm','--prefix','tools/simurgh-explorer','run','build']],'counts':explorer,'production_build':'passed','http':read(work/'explorer-final-revision-http.json')},
 'supplement':{'source_commit':base['source_commit'],'python_suites':len(suites),'python_tests':sum(r['tests'] for r in suites),'agentdojo_tests':pytest,'rust':rust,'commands':supplement},
 'hosted':{'readiness':hosted,'native':native,'macos_tests':10,'windows_tests':11,'windows_fixture_build':'passed','artifact_download':'HTTP 403; job logs and GitHub status retained'},
 'browser':browser,'initial_attempts':[{'source_commit':read(folder/'environment.json')['source_commit'],'base':steps(folder/'base.log'),'e2e':steps(folder/'e2e.log')} for folder in (initial,candidate)],
 'delta_after_base_and_supplement':delta,'delta_verification':'All changes since the complete base run are listed; final root, full E2E and explorer checks cover changed code/tests. Native and Python implementation bytes are unchanged.',
 'credential_retry':read(dest/'refusal-retry-2.json'),'logs':{'path':'logs.zip','sha256':digest(archive),'entries':len(manifest),'manifest':'manifest.json'},
 'limitations':['Managed browser file navigation blocks real browser parity and accessibility validation.','Model API requests returned HTTP 401; organization project listing HTTP 403.','OpenAI Platform connector requires reauthentication; no new key was created.','Classmate reproduction is owner-managed and excluded.','Historical verifier limitations remain open in GAPS.md.','Prepared dependency installs and documented Docker npm cache were reused.','Some historical reproduction scripts mutate fixtures only inside disposable checkouts.','Suite counts are separate and must not be summed as unique tests.']}
(dest/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'base':validation['base']['steps'],'e2e':validation['e2e']['steps'],'root':unit['tests'],'explorer':explorer['tests'],'python':validation['supplement']['python_tests'],'archive_entries':len(manifest)}))

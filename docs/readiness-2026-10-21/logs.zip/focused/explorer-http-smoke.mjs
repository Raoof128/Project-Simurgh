import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const root = process.cwd();
const { createExplorerServer } = await import(pathToFileURL(resolve(root, 'tools/simurgh-explorer/serve.mjs')));
const { parseBundle, summary, queryRecords } = await import(pathToFileURL(resolve(root, 'tools/simurgh-explorer/core.mjs')));
const server = createExplorerServer();
await new Promise(r => server.listen(0, '127.0.0.1', r));
try {
  const base = `http://127.0.0.1:${server.address().port}`;
  const page = await fetch(base);
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  const html = await page.text();
  const assets = [...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)].map(m => m[1]);
  assert.equal(assets.length, 2);
  for (const path of assets) {
    const response = await fetch(new URL(path, base));
    assert.equal(response.status, 200);
    assert.ok((await response.text()).length > 100);
  }
  const response = await fetch(base + '/evidence.json');
  assert.equal(response.status, 200);
  const bundle = parseBundle(await response.text());
  assert.equal(bundle.records.length, 288);
  const cli = (...args) => JSON.parse(execFileSync(process.execPath, ['tools/simurgh-explorer/cli.mjs', ...args], {encoding:'utf8'}));
  assert.deepEqual(summary(bundle), cli('summary').data);
  assert.deepEqual(queryRecords(bundle, {kind:'unauthorized',control:'credential_only'}), cli('records','--kind','unauthorized','--control','credential_only').data);
  assert.equal((await fetch(base, {method:'POST'})).status, 405);
  assert.equal((await fetch(base, {headers:{Origin:'https://example.invalid'}})).status, 403);
  console.log(JSON.stringify({status:'passed',assets:assets.length,records:bundle.records.length,cli_summary_agrees:true,cli_unauthorized_filter_agrees:true,write_refused:true,cross_origin_refused:true,browser_rendering:'not_exercised'},null,2));
} finally {
  await new Promise(r => server.close(r));
}

from pathlib import Path
import json,hashlib,re,zipfile
work=Path('/workspace/work/simurgh-readiness-2026-10-21');out=work/'refusal-upload-3';dest=Path('docs/readiness-2026-10-21')
rows=json.loads((out/'results.json').read_text());frozen=json.loads((dest/'refusal-requests.json').read_text())
expected={'baseline-active':('observed',1,0),'clarified-active':('observed',1,0),'clarified-stop':('declined',0,0),'clarified-unknown':('declined',0,1)}
assert [a['id'] for a in rows['arms']]==[r['id'] for r in frozen]
summary=[]
for a,f in zip(rows['arms'],frozen):
 raw=json.loads((out/'api'/(a['id']+'.json')).read_text());o=a['observed']
 assert raw['request']==f['request'] and raw['status']=='received' and raw['http_status']==200
 assert (o['status'],len(o['new_effects']),len(o['before_effects']))==expected[a['id']]
 for effect in o['new_effects']:
  assert effect['action']['resource']==a['proposal']['arguments']['resource']
  assert effect['action']['content']==a['proposal']['arguments']['content']
 assert a['usage']==raw['response']['usage']
 summary.append({'id':a['id'],'http_status':200,'status':o['status'],'proposal_status':a['proposal']['status'],'new_effects':len(o['new_effects']),'prior_effects':len(o['before_effects']),'usage':a['usage']})
forced=[]
assert len(rows['forced_controls'])==8
for o in rows['forced_controls']:
 active=o['case'] in ('active','authorized_reopen','operator_restart')
 assert o['status']==('observed' if active else 'blocked')
 assert len(o['new_effects'])==int(active)
 assert len(o['before_effects'])==int(o['case']=='unknown_prior')
 forced.append({'case':o['case'],'status':o['status'],'new_effects':len(o['new_effects']),'prior_effects':len(o['before_effects'])})
budget=[json.loads(l) for l in (out/'diagnostic-budget.jsonl').read_text().splitlines()]
assert len(budget)==4 and [r['id'] for r in budget]==[f['id'] for f in frozen]
assert all(r['reserved_usd']=='0.25' for r in budget)
keys=set(re.findall(r'sk-[A-Za-z0-9_-]{20,}',Path('/workspace/attachments/4a3ad2f2-bf33-49be-b2cb-bc02a9cfe4a3/OpenAI Key.txt').read_text()));assert len(keys)==1
secret=next(iter(keys)).encode()
entries={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl')}
for n in ('refusal-upload-3-declaration.json','refusal-upload-3-preflight.json','refusal-upload-3.log','publish-upload.py'):entries[n]=work/n
manifest=[]
for name,p in sorted(entries.items()):
 b=p.read_bytes()
 assert secret not in b and not re.search(rb'(?<![A-Za-z0-9_-])sk-[A-Za-z0-9_-]{20,}|-----BEGIN (?:[A-Z ]+)?PRIVATE KEY-----',b),name
 manifest.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=dest/'refusal-upload-3.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in manifest:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
receipt={'schema':'simurgh.readiness.uploaded-credential-diagnostic.v1','declaration':json.loads((work/'refusal-upload-3-declaration.json').read_text()),'source_commit':rows['source_commit'],'command':['/workspace/.venvs/simurgh-assurance-workflow/bin/python','-B','docs/readiness-2026-10-21/refusal_diagnostic.py','--out','<fresh-output-directory>'],'exit_code':0,'arms':summary,'forced_controls':forced,'attempts':len(budget),'reserved_usd':'1.00','billed_usd':None,'interpretation':'Baseline and clarified active arms both acted; this sample does not attribute behavior to clarification or resolve the earlier refusal causally.','provider_lifecycle':'not tested with uploaded credential','credential_handling':'Read from user attachment into child process environment; no env file or repository credential write.','preflight':json.loads((work/'refusal-upload-3-preflight.json').read_text()),'verification':{'frozen_request_identity':True,'all_arm_status_and_effect_counts':True,'all_forced_control_counts':True,'budget_bound':True,'archive_secret_scan':True},'archive':{'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_entries':len(manifest)}}
(dest/'refusal-upload-3.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'requests':len(summary),'forced_controls':len(forced),'archive_entries':len(manifest),'input_tokens':sum(a['usage']['input_tokens'] for a in summary),'output_tokens':sum(a['usage']['output_tokens'] for a in summary),'checks':'passed'}))
